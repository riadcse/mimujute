<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            ADMIN DEPERTMENT | Staff
                        </h1>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-12">
                    <div class="panel panel-info">
                      <div class="panel-heading">ADD NEW STAFF</div>
                      <div class="panel-body">
                        <form class="form-horizontal" action="<?php echo e(url('/')); ?>/addstaff" method="post">
                        <?php echo e(csrf_field()); ?>

                          <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">নাম</label>
                            <div class="col-sm-10">
                              <input type="text" name="name" class="form-control" id="name" placeholder="Name">
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="designation" class="col-sm-2 control-label">পদবী</label>
                            <div class="col-sm-10">
                              <input type="text" class="form-control" id="designation" name="designation" placeholder="Designation">
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="phone" class="col-sm-2 control-label">ফোন</label>
                            <div class="col-sm-10">
                              <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone Number">
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="address" class="col-sm-2 control-label">ঠিকানা</label>
                            <div class="col-sm-10">
                              <input type="text" class="form-control" id="address" name="address" placeholder="Enter Address">
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                              <button type="submit" class="btn btn-success">Add Staff</button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                    
                        
                    </div>
                </div>

                   <div class="row">
                    <div class="col-md-12">

                    <div class="panel panel-primary">
					  <div class="panel-heading">কর্মকর্তা/কর্মচারীদের লিস্ট </div>
					  <div class="panel-body">
					      <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ক্রমিক নং</th>
                                        <th>নাম</th>
                                        <th>পদবী</th>
                                        <th>সর্বমোট পাওনা (টাকা)</th>
                                        <th>সর্বমোট পরিশোধ (টাকা)</th>
                                        <th>অপরিশোধিত পাওনা (টাকা)</th>
                                        <th>অ্যাকশন</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php ($i = 1); ?>
								<?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>	
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><a href="<?php echo e(url('/')); ?>/staffinfo/<?php echo e($staff->id); ?>"><?php echo e($staff->name); ?></a></td>
                                        <td><?php echo e($staff->designation); ?></td>
                                        <td><?php echo e($staff->totaldue); ?></td>
                                        <td><?php echo e($staff->totalpaid); ?></td>
                                        <td><?php echo e($staff->totaldue - $staff->totalpaid); ?></td>
                                        <td>
                                        <?php if( $staff->totaldue > 1): ?>
                                        	<a href="#"><button class="btn btn-danger disabled">DELETE</button></a>
                                        <?php else: ?> 
                                            <a onclick="return confirm('Are you sure you want to delete this staff?');" href="<?php echo e(url('/')); ?>/deletestaff/<?php echo e($staff->id); ?>"><button class="btn btn-danger">DELETE</button></a>
                                        <?php endif; ?>
                                         </td>
                                    </tr>
                                    <?php ($i++); ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($staffs->links()); ?>

                        </div>
					  </div>
					</div>

                    </div>
                </div>
                <!-- /.row -->



    </div> <!-- /.container-fluid -->
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>