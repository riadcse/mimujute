<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            DAILY REPORT
                        </h1>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-12">
                    <div class="panel panel-primary">
                      <div class="panel-heading">নতুন হিসাব</div>
                      <div class="panel-body">

                      <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ব্যাবসায়ী</th>
                                        <th>লট নং</th>
                                        <th>ক্রয়কৃত পাটের পরিমান (মণ)</th>
                                        <th>পাটের দর</th>
                                        <th>মোট মূল্য</th>
                                        <th>অ্যাকশন</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <form class="form-horizontal" action="<?php echo e(url('/')); ?>/addReport" method="post">
                                    <?php echo e(csrf_field()); ?>

                                        <td>
                                          <select class="form-control" name="supplierid">
                                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?> (<?php echo e($supplier->mokam); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                          </select>
                                        </td>
                                        <td>
                                            <input type="text" name="lot" class="form-control" id="lot" placeholder="0">
                                        </td>
                                        <td>
                                            <input type="text" onkeyup="findTotal()" name="quantity" class="form-control" id="quantity" placeholder="0">
                                        </td>
                                        <td>
                                            <input type="text" onkeyup="findTotal()" name="price" class="form-control" id="price" placeholder="0">
                                        </td>
                                        <td>
                                            <input type="text" name="totalprice" class="form-control" id="totalprice" placeholder="0">
                                        </td>
                                        <td>
                                            <button type="submit" class="btn btn-success">SAVE</button>
                                        </td>
                                    </form>
                                    </tr>
                                </tbody>
                            </table>                    

                      </div>
                    </div>
                    
                        
                    </div>
                </div>
                </div>

                   <div class="row">
                    <div class="col-md-12">

                    <div class="panel panel-primary">

					  <div class="panel-heading">
                        <h3 class="panel-title pull-left">
                            পাট খরিদ, পরিশোধ ও দেনাপাওনা প্রতিবেদন 
                        </h3>
                          <form class="navbar-form navbar-right" method="post" action="<?php echo e(url('/')); ?>/DailyReportFilter">
                          <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                              <input name="fromdate" type="text" class="form-control fromdate" data-provide="datepicker" format="dd-mm-yyyy" placeholder="DD-MM-YYYY">
                            </div>
                            <div class="form-group">
                              <input name="todate" type="text" class="form-control todate" data-provide="datepicker" placeholder="DD-MM-YYYY">
                            </div>
                            <button type="submit" class="btn btn-success">FILTER</button>
                          </form><br><br>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curdate): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php if($loop->last): ?>
                                <?php echo e(date('d-F', strtotime($curdate->date))." থেকে "); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curdate): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php if( $loop->first ): ?>
                                <?php echo e(date('d-F-Y', strtotime($curdate->date))); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                           <div class="clearfix"></div>
                      </div>
                      
					  <div class="panel-body">
						
						<div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ক্রমিক নং</th>
                                        <th>তারিখ</th>
                                        <th>ব্যাবসায়ীর নাম</th>
                                        <th>মোকাম</th>
                                        <th>লট নং</th>
                                        <th>ওজন (মণ)</th>
                                        <th>দর</th>
                                        <th>মোট মূল্য</th>
                                        <th>সর্বমোট পাওনা</th>
                                        <th>সর্বমোট পরিশোধ</th>
                                        <th>অপরিশোধিত পাওনা</th>
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php ($i=1); ?>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($transaction->date))); ?></td>
                                        <td><a href="<?php echo e(url('/')); ?>/supplierinfo/<?php echo e($transaction->id); ?>"><?php echo e($transaction->name); ?></a></td>
                                        <td><?php echo e($transaction->mokam); ?></td>
                                        <td><?php echo e($transaction->lot); ?></td>
                                        <td><?php echo e($transaction->quantity); ?></td>
                                        <td><?php echo e($transaction->price); ?></td>
                                        <td><?php echo e($transaction->totalprice); ?></td>
                                        <td><?php echo e($transaction->totaldue); ?></td>
                                        <td><?php echo e($transaction->totalpaid); ?></td>
                                        <td><?php echo e($transaction->totaldue - $transaction->totalpaid); ?></td>
                                    </tr>
                                    <?php ($i++); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($transactions->links()); ?>

                        </div>	

					  </div> <!--  panel end -->
					</div>

                    </div>
                </div>
             



    </div> <!-- /.container-fluid -->

<script type="text/javascript">
	function findTotal(){
	    quantity = document.getElementById("quantity").value;
	    price = document.getElementById("price").value;
	    totalprice=0;
	    totalprice = quantity*price;
	    document.getElementById("totalprice").value = totalprice;
	}
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>