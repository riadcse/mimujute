<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            সিকিউরিটি গার্ডদের মাসিক বেতনের বিবরন
                        </h1>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-12">
                    <div class="panel panel-primary">
                      <div class="panel-heading">নতুন হিসাব</div>
                      <div class="panel-body">

                      <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="salarysheet">
                                    <tr>
                                        <th style="text-align:center; vertical-align: middle;">গার্ড</th>
                                        <th style="text-align:center; vertical-align: middle;">মোট বেতন</th>
                                        <th style="text-align:center; vertical-align: middle;">কর্তন</th>
                                        <th style="text-align:center; vertical-align: middle;">নীট বেতন</th>
                                        <th style="text-align:center; vertical-align: middle;">মন্তব্য</th>
                                        <th style="text-align:center; vertical-align: middle;"></th>
                                </thead>
                                <tbody>

                                    <tr>
                                    <form class="form-horizontal" action="<?php echo e(url('/')); ?>/addgaurdReport" method="post">
                                    <?php echo e(csrf_field()); ?>

                                        <td>
                                          <select class="form-control" name="gaurd_id" style="width: inherit;">

                                          <?php $__currentLoopData = $gaurds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gaurd): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                            <option value="<?php echo e($gaurd->id); ?>"><?php echo e($gaurd->name); ?> ( <?php echo e($gaurd->designation); ?> )</option>

                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                          </select>
                                        </td>
                                        <td><input type="text" name="salary" id="salary" class="form-control" placeholder="0" onkeyup="findTotal()"></td>
                                        <td><input type="text" name="minus" id="minus" class="form-control" placeholder="0" onkeyup="findTotal()"></td>
                                        <td><input type="text" name="totalsalary" id="totalsalary" class="form-control" placeholder="0"></td>
                                        <td><input type="text" name="description" id="description" class="form-control" placeholder="..."></td>
                                        <td><button type="submit" class="btn btn-success">SAVE</button></td>
                                    </form>
                                    </tr>

                                </tbody>
                            </table>                

                      </div>
                      </div>
                      </div>
                    </div>
                    
                        
                    </div>

                   <div class="row">
                    <div class="col-md-12">

                    <div class="panel panel-primary">
					  <div class="panel-heading">
                        <h3 class="panel-title pull-left">
                            সিকিউরিটি গার্ডদের মাসিক বেতনের বিবরন
                        </h3>
                          <form class="navbar-form navbar-right" method="post" action="<?php echo e(url('/')); ?>/gaurdreportfilter">
                          <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                              <input name="fromdate" type="text" class="form-control fromdate" data-provide="datepicker" format="dd-mm-yyyy" placeholder="DD-MM-YYYY">
                            </div>
                            <div class="form-group">
                              <input name="todate" type="text" class="form-control todate" data-provide="datepicker" placeholder="DD-MM-YYYY">
                            </div>
                            <button type="submit" class="btn btn-success">FILTER</button>
                          </form><br><br>
                        <?php $__currentLoopData = $gaurd_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curdate): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php if($loop->last): ?>
                                <?php echo e(date('d-F', strtotime($curdate->date))." থেকে "); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <?php $__currentLoopData = $gaurd_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curdate): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php if( $loop->first ): ?>
                                <?php echo e(date('d-F-Y', strtotime($curdate->date))); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                           <div class="clearfix"></div>
                      </div>
					  <div class="panel-body">
						
						<div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="salarysheet">
                                    <tr>
                                        <th style="text-align:center; vertical-align: middle;">ক্রমিক নং</th>
                                        <th style="text-align:center; vertical-align: middle;">তারিখ</th>
                                        <th style="text-align:center; vertical-align: middle;">নাম</th>
                                        <th style="text-align:center; vertical-align: middle;">পদবী</th>
                                        <th style="text-align:center; vertical-align: middle;">মোট বেতন</th>
                                        <th style="text-align:center; vertical-align: middle;">কর্তন</th>
                                        <th style="text-align:center; vertical-align: middle;">নীট বেতন</th>
                                        <th style="text-align:center; vertical-align: middle;">মন্তব্য</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php ($i=1); ?>
                                    <?php $__currentLoopData = $gaurd_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gaurd_report): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($gaurd_report->date))); ?></td>
                                        <td><a href="<?php echo e(url('/')); ?>/gaurdinfo/<?php echo e($gaurd_report->id); ?>"><?php echo e($gaurd_report->name); ?></a></td>
                                        <td><?php echo e($gaurd_report->designation); ?></td>
                                        <td><?php echo e($gaurd_report->salary); ?></td>
                                        <td><?php echo e($gaurd_report->minus); ?></td>
                                        <td><?php echo e($gaurd_report->totalsalary); ?></td>
                                        <td><?php echo e($gaurd_report->description); ?></td>
                                    </tr>
                                    <?php ($i++); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($gaurd_reports->links()); ?>

                        </div>	

					  </div> <!--  panel end -->
					</div>

                    </div>
                </div>
             



    </div> <!-- /.container-fluid -->

<script type="text/javascript">
	function findTotal(){
        salary = document.getElementById("salary").value;
        minus = document.getElementById("minus").value;
        totalsalary = 0;
	    totalsalary = Number(salary)-Number(minus);
	    document.getElementById("totalsalary").value = totalsalary;
    
	}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>